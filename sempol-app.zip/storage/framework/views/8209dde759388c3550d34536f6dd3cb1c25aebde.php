
<?php $__env->startSection('title'); ?>
    <title>Guru SMKN 1 Sempol</title>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<style>
    .img-fit {
        display: block;
        max-height: 200px;
        width: auto;
        height: auto;
        object-fit: cover !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?> 
    <section id="page-title">
        <div class="container clearfix">
            <h1>Guru SMKN 1 Sempol</h1>
        </div>
    </section>

    <div class="container clearfix">
        <div class="heading-block topmargin-sm center">
    </div>
    <div class="row">
        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guruschool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <div class="col-lg-3 col-md-6 bottommargin">
                <div class="team">
                    <div class="team-image">
                        <img src="<?php echo e(asset('foto_guru/'.$guruschool->foto)); ?>" alt="Image" class="mb-0 img-fit">
                    </div>
                <div class="team-desc team-desc-bg">
                    <div class="team-title">
                        <h4>   <?php echo $guruschool->nama_guru; ?></h4>
                        <span><?php echo $guruschool->mapel->nama_mapel; ?></span>
                    </div>
                </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/guru.blade.php ENDPATH**/ ?>