
<?php $__env->startSection('title'); ?>
    <title>Kepala Sekolah</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="page-title">
    <div class="container clearfix">
        <h1>Profil Kepala SMKN 1 Sempol</h1>
    </div>
</section>
        <div class="container clearfix">
            <div class="topmargin-sm center">
        </div>
            <div class="row col-mb-50">
                <div class="col-md-6 d-none d-md-flex align-self-end">
                    <img src="<?php echo e(asset('foto_kepsek/'.$kepala->foto)); ?>" alt="Image" class="mb-0">
                </div>
                <div class="col-md-6 mb-5 subscribe-widget">
                    <div>
                    <label>Nama: <?php echo $kepala->nama; ?> </label><br>
                    <label>NIP:  <?php echo $kepala->nip; ?>  </label><br>
                    <label>Pendidikan Terakhir: <?php echo $kepala->riwayat; ?> </label><br>
                    <?php echo $kepala->ucapan; ?> <br>
                    <div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/kepalasekolah.blade.php ENDPATH**/ ?>