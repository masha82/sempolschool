
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>Prestasi Sekolah</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
    <section id="page-title">
        <div class="container clearfix">
            <h1>Prestasi SMKN 1 Sempol</h1>
        </div>
    </section>
    
    <div class="container clearfix">
        <div class="heading-block topmargin-sm center">
    </div>
        <div class="row gutter-40 col-mb-80">
            <div class="postcontent col-lg-12">
                <div id="posts" class="row gutter-40 mb-0">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="entry col-12 mt-0 mb-0">
                            <div class="grid-inner row g-0">
                                <div class="col-md-4">
                                    <a class="entry-image" href="#" data-lightbox="image"><img
                                            src="<?php echo e(asset('gambar_prestasi/' . $item->foto)); ?>"
                                            alt="Standard Post with Image"></a>
                                </div>
                                <div class="col-md-8 ps-md-4">
                                    <div class="entry-title title-sm">
                                        <h2><a href="<?php echo e(route('achievement.show',$item->id)); ?>"><?php echo e($item->nama_prestasi); ?></a></h2>
                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><i class="icon-calendar3"></i>
                                                <?php echo e(\Carbon\Carbon::parse($item->created_at)->isoFormat('dddd, D MMMM Y')); ?>

                                            </li>
                                        </ul>
                                    </div>
                                    
                                </div>
                            </div>
                            <hr>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row mb-3">
                        <?php echo e($data->links('layouts.paginate')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/prestasi.blade.php ENDPATH**/ ?>