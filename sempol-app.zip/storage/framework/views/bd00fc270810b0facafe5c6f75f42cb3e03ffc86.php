
<?php $__env->startSection('title'); ?>
    <title>Pengurus OSIS</title>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<style>
    .img-fit {
        display: block;
        max-height: 200px;
        width: auto;
        height: auto;
        object-fit: cover !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?> 
    <section id="page-title">
        <div class="container clearfix">
            <h1>Pengurus OSIS SMKN 1 Sempol</h1>
        </div>
    </section>

    <div class="container clearfix">
        <div class="heading-block topmargin-sm center">
    </div>
    <div class="row">
        <?php $__currentLoopData = $pengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengurusosis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <div class="col-lg-3 col-md-6 bottommargin">
                <div class="team">
                    <div class="team-image">
                        <img src="<?php echo e(asset('foto_pengurus/'.$pengurusosis->foto)); ?>" alt="Image" class="mb-0 img-fit">
                    </div>
                <div class="team-desc team-desc-bg">
                    <div class="team-title">
                        <h4>   <?php echo $pengurusosis->nama; ?></h4>
                        <span><?php echo $pengurusosis->jabatan; ?></span>
                    </div>
                </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/pengurusosis.blade.php ENDPATH**/ ?>