<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demos/demo-dentist.css')); ?>" type="text/css" />
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>SMKN 1 Sempol</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div role="main" class="main">

    <div class="p-relative">
        <div class="owl-carousel owl-carousel-light owl-carousel-light-init-fadeIn owl-theme manual nav-style-1 nav-arrows-thin nav-font-size-lg custom-nav-1 custom-nav-1-pos-1 p-relative mb-0" data-plugin-options="{'autoplay': true, 'autoplayTimeout': 7000}" data-dynamic-height="['calc(100vh - 305px)','calc(100vh - 305px)','calc(100vh - 305px)','calc(100vh - 305px)','calc(100vh - 305px)']" style="height: calc(100vh - 305px);">
            <div class="owl-stage-outer">
                <div class="owl-stage">

                    <!-- Carousel Slide 1 -->
                    <div class="owl-item p-relative overflow-hidden">
                        <div class="background-image-wrapper p-absolute d-none d-lg-block w-100 h-100 top-0 right-0 bottom-0" style="background-image: url(img/demos/dentist/slides/slide-dentist-1-1.jpg); background-size: cover; max-width: 50vw;"></div>

                        <div class="background-image-wrapper p-absolute w-100 h-100 top-0 left-0 bottom-0" style="background-image: url(img/demos/dentist/slides/slide-dentist-1-2.jpg); background-size: cover; max-width: 50vw;"></div>

                        <div class="container p-relative z-index-3 h-100">
                            <div class="row align-items-center h-100">
                                <div class="col-lg-8 col-xl-6 text-center text-md-start">
                                    <h2 class="font-weight-semi-bold text-color-dark text-9 text-md-12 line-height-2 mb-3 appear-animation" data-appear-animation="fadeInUpShorterPlus" data-appear-animation-delay="200" data-plugin-options="{'minWindowWidth': 0}">SMKN 1 SEMPOL BONDOWOSO</h2>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Carousel Slide 2 -->
                    <div class="owl-item p-relative overflow-hidden">
                        <div class="background-image-wrapper p-absolute d-none d-lg-block w-100 h-100 top-0 right-0 bottom-0" style="background-image: url(<?php echo e(asset('assets/img/sempol/header.jpeg')); ?>); background-size: cover;"></div>

                        <div class="container p-relative z-index-3 h-100">
                            <div class="row align-items-center justify-content-end h-100">
                                <div class="col-lg-8 col-xl-6 text-center text-md-start">
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="owl-nav">
                <button type="button" role="presentation" class="owl-prev" aria-label="Previous"></button>
                <button type="button" role="presentation" class="owl-next" aria-label="Next"></button>
            </div>
        </div>

        <div class="p-absolute custom-el-pos-1 d-none d-xl-block z-index-2">
            <img width="353" height="407" src="<?php echo e(asset('assets/img/demos/dentist/generic/generic-3.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-tertiary'}" />
        </div>

        <div class="p-absolute custom-el-pos-2 rotate-l-65 d-none d-xl-block z-index-2">
            <img width="330" height="346" src="<?php echo e(asset('assetsimg/demos/dentist/generic/generic-4.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}" />
        </div>
    </div>

    <div id="home-intro" class="home-intro bg-primary p-relative z-index-3 m-0">
        <div class="container py-2">
            <div class="row align-items-center text-center text-md-start">
                <div class="col-lg-9 mb-3 mb-lg-0">
                    <p class="text-color-light text-4-5 font-weight-medium line-height-4 mb-0">
                        <strong>Selamat Datang di Website SMKN 1 SEMPOL</strong> 
                        
                    </p>
                </div>
                
            </div>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <div class="col py-2">

                <div class="featured-boxes featured-boxes-style-9">
                    <div class="row">
                        <div class="col-lg-4 px-lg-3">
                            <div class="featured-box featured-box-secondary">
                                <div class="box-content">
                                    <span class="icon-featured icon-featured-lg">
                                        <img height="100" src="<?php echo e(asset('assets/img/demos/dentist/icons/icon-appointment.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-tertiary mt-1'}" />
                                    </span>
                                    <h4 class="font-weight-semi-bold mt-3 pt-2 mb-3 text-5-5 text-color-dark">Kompetensi</h4>
                                    <p class="mb-0 text-3-5 font-weight-medium">Jumlah</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 px-lg-3">
                            <div class="featured-box featured-box-primary">
                                <div class="box-content">
                                    <span class="icon-featured icon-featured-lg">
                                        <img height="100" src="<?php echo e(asset('assets/img/demos/dentist/icons/icon-1.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-tertiary mt-1'}" />
                                    </span>
                                    <h4 class="font-weight-semi-bold mt-3 pt-2 mb-3 text-5-5 text-color-dark">Peserta Didik</h4>
                                    <p class="mb-0 text-3-5 font-weight-medium">Jumlah</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 px-lg-3">
                            <div class="featured-box featured-box-secondary">
                                <div class="box-content">
                                    <span class="icon-featured icon-featured-lg">
                                        <img height="100" src="<?php echo e(asset('assets/img/demos/dentist/icons/icon-2.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-tertiary mt-1'}" />
                                    </span>
                                    <h4 class="font-weight-semi-bold mt-3 pt-2 mb-3 text-5-5 text-color-dark">Guru</h4>
                                    <p class="mb-0 text-3-5 font-weight-medium">Jumlah</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 px-lg-3">
                            <div class="featured-box featured-box-tertiary">
                                <div class="box-content">
                                    <span class="icon-featured icon-featured-lg">
                                        <img height="100" src="<?php echo e(asset('assets/img/demos/dentist/icons/icon-3.svg')); ?>" alt="" data-icon data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-tertiary mt-1'}" />
                                    </span>
                                    <h4 class="font-weight-semi-bold mt-3 pt-2 mb-3 text-5-5 text-color-dark">Staf</h4>
                                    <p class="mb-0 text-3-5 font-weight-medium">Jumlah</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    

    

    

    

    

    

    

</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/welcome.blade.php ENDPATH**/ ?>