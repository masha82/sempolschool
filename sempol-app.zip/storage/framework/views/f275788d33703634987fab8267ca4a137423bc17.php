<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/style.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/dark.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/font-icons.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/animate.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/magnific-popup.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/gallerycss/custom.css')); ?>" type="text/css"/>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>Galeri</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="container topmargin bottommargin-lg">
            <div class="mx-auto" style="max-width: 700px">
                <h2 class="mb-2 nott center ls0 gradient-text gradient-horizon">GALERI SMK NEGERI 1 SEMPOL</h2>
            </div>
        </div>
    </div>
</div>
<div class="row posts-md col-mb-30">
    <div class="masonry-thumbs grid-container grid-3" data-big="2" data-lightbox="gallery">
        <?php $__currentLoopData = $galerii; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="grid-item" href="<?php echo e(asset('galerifoto/' . $item->foto)); ?>"
               data-lightbox="gallery-item"><img
                    src="<?php echo e(asset('galerifoto/' . $item->foto)); ?>" alt="Gallery Thumb 1"></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/galleryjs/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/galleryjs/plugins.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/galleryjs/functions.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/galeri.blade.php ENDPATH**/ ?>