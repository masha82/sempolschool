<?php $__env->startSection('title'); ?>
    <title>Video SMKN 1 Sempol</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="mb-4">
        <div class="container clearfix mt-5 mb-4">
            <div class="row clearfix">
                <!-- Second Posts Area
                ============================================= -->
                <div class="col-lg-12 mb-4">
                    <!-- Gallery Slider
                    ============================================= -->
                    <h4 style="background: #9ADCFF" class="ls1 text-uppercase fw-bold">
                        Video</h4>
                    <!-- Flex Thumbs Slider
                    ============================================= -->
                    <div class="row col-mb-50">
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mt-0">
                                <!-- Post Article -->
                                <div class="posts-md">
                                    <div class="entry">
                                        <div class="entry-title title-sm nott">
                                            <h3 class="mb-0"><a
                                                    href="#"><?php echo e($video->keterangan); ?></a>
                                            </h3>
                                        </div>
                                        <div class="entry-image img-fit">
                                            <?php echo $video->link; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($videos->links('layouts.paginate')); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/video.blade.php ENDPATH**/ ?>