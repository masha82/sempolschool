
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>Siswa</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
    <section id="page-title">
        <div class="container clearfix">
            <h1>Siswa SMKN 1 Sempol</h1>
        </div>
    </section>
            
    <div>
        <div class="container topmargin bottommargin-lg clearfix">
            <div class="row col-mb-50 mb-0">
                <div class="col-lg-8">
                    <table class="table table-striped" id="myTable">
                        <thead>
                        <tr>
                            <th>Tahun Pelajaran</th>
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>Jumlah</th>
                            <th>Link</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.all.min.js"></script>
    <script>
        $(document).ready(function () {
            var table = $('#myTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('siswasekolah.data')); ?>",
                columns: [{
                    data: 'thn_ajaran',
                    name: 'thn_ajaran'
                },
                    {
                        data: 'kelas',
                        name: 'kelas'
                    },
                    {
                        data: 'jurusan',
                        name: 'jurusan'
                    },
                    {
                        data: 'jumlah',
                        name: 'jumlah'
                    },
                    {
                        data: 'link',
                        name: 'link'
                    }
                
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/siswa.blade.php ENDPATH**/ ?>