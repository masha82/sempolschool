<?php $__env->startSection('title'); ?>
    <title>Tentang Sekolah</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="page-title">
    <div class="container clearfix">
        <h1>Tentang SMKN 1 Sempol</h1>
    </div>
</section>
        <div class="container clearfix">
            <div class="topmargin-sm center">
        </div>
                
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sempolschool\resources\views/school.blade.php ENDPATH**/ ?>